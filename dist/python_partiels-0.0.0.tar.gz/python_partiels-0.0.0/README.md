# Python wrapper for Partiels

The wrapper use subprocess to access Partiels's Command Line Interface.

[The Partiels Github page](https://github.com/Ircam-Partiels)
